package main;

import java.util.*;

/**
 * La clase faseSemantica se encarga del análisis semántico del compilador.
 * Recorre el Árbol Sintáctico Abstracto (AST) generado durante la fase sintáctica
 * y verifica que todos los identificadores utilizados estén correctamente declarados.
 */
public class faseSemantica {
    private final List<String> errores;
    private final Set<String> variablesDeclaradas;

    /**
     * Constructor de la clase faseSemantica.
     * Inicializa la lista de errores y el conjunto de variables declaradas.
     */
    public faseSemantica() {
        this.errores = new ArrayList<>();
        this.variablesDeclaradas = new HashSet<>();
    }

    /**
     * Inicia el proceso de análisis semántico sobre el AST proporcionado.
     *
     * @param ast El nodo raíz del Árbol Sintáctico Abstracto.
     */
    public void analizar(NodoAST ast) {
        recorrerAST(ast);
    }

    /**
     * Recorre el AST de manera recursiva y aplica las verificaciones semánticas correspondientes.
     *
     * @param nodo El nodo actual del AST que se está procesando.
     */
    private void recorrerAST(NodoAST nodo) {
        if (nodo instanceof ProgramaNodo) {
            visitar((ProgramaNodo) nodo);
        } else if (nodo instanceof AsignacionNodo) {
            visitar((AsignacionNodo) nodo);
        } else if (nodo instanceof OperacionNodo) {
            visitar((OperacionNodo) nodo);
        } else if (nodo instanceof IdentificadorNodo) {
            visitar((IdentificadorNodo) nodo);
        } else if (nodo instanceof NumeroNodo) {
            visitar((NumeroNodo) nodo);
        }
    }

    /**
     * Visita un nodo de tipo ProgramaNodo y procesa sus expresiones.
     *
     * @param nodo El nodo ProgramaNodo a visitar.
     */
    private void visitar(ProgramaNodo nodo) {
        for (NodoAST expresion : nodo.expresiones) {
            recorrerAST(expresion);
        }
    }

    /**
     * Visita un nodo de tipo AsignacionNodo y procesa su expresión.
     * Marca el identificador como declarado después de procesar la expresión.
     *
     * @param nodo El nodo AsignacionNodo a visitar.
     */
    private void visitar(AsignacionNodo nodo) {
        recorrerAST(nodo.expresion);
        // Después de procesar la expresión, marcamos la variable como declarada
        variablesDeclaradas.add(nodo.identificador);
    }

    /**
     * Visita un nodo de tipo OperacionNodo y procesa sus operandos.
     *
     * @param nodo El nodo OperacionNodo a visitar.
     */
    private void visitar(OperacionNodo nodo) {
        recorrerAST(nodo.izquierdo);
        recorrerAST(nodo.derecho);
    }

    /**
     * Visita un nodo de tipo IdentificadorNodo y verifica si ha sido declarado.
     *
     * @param nodo El nodo IdentificadorNodo a visitar.
     */
    private void visitar(IdentificadorNodo nodo) {
        if (!variablesDeclaradas.contains(nodo.nombre)) {
            String errorMessage = String.format("Error [Fase Semántica]: La línea %d contiene un error, no declarado identificador '%s'", nodo.numeroLinea, nodo.nombre);
            //System.err.println(errorMessage);
            errores.add(errorMessage);
        }
    }

    /**
     * Visita un nodo de tipo NumeroNodo.
     * Los números siempre son válidos, por lo que no se realiza ninguna acción.
     *
     * @param nodo El nodo NumeroNodo a visitar.
     */
    private void visitar(NumeroNodo nodo) {
        // Los números siempre son válidos
    }

    /**
     * Obtiene la lista de errores encontrados durante el análisis semántico.
     *
     * @return Una lista de cadenas que describen los errores encontrados.
     */
    public List<String> getErrores() {
        return errores;
    }
}
