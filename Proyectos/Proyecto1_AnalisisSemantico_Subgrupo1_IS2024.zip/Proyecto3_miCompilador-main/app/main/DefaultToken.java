package main;

/**
 * Clase DefaultToken que implementa la interfaz Token.
 * Esta clase representa un token en el analizador léxico,
 * incluyendo su valor (lexema), tipo y número de línea.
 */
public class DefaultToken implements Token {
    private final String llave;
    private final TipoToken tipo;
    private final int linea;

    /**
     * Constructor de la clase DefaultToken.
     *
     * @param llave  Valor del token (lexema).
     * @param tipo   Tipo del token (TipoToken).
     * @param linea  Número de línea del token.
     */
    public DefaultToken(String llave, TipoToken tipo, int linea) {
        this.llave = llave;
        this.tipo = tipo;
        this.linea = linea;
    }

    /**
     * Obtiene el valor del token.
     *
     * @return El valor del token.
     */
    @Override
    public String obtenerValor() {
        return llave;
    }

    /**
     * Obtiene el tipo del token.
     *
     * @return El tipo de token.
     */
    @Override
    public TipoToken obtenerAtributo() {
        return tipo;
    }

    /**
     * Obtiene el número de línea del token.
     *
     * @return El número de línea.
     */
    @Override
    public int obtenerLinea() {
        return linea;
    }

    /**
     * Devuelve una representación en formato de cadena del token.
     * La representación incluye el valor, tipo y número de línea del token.
     *
     * @return Una cadena que representa el token con su valor, tipo y línea.
     */
    @Override
    public String toString() {
        return "Valor: " + llave + ", Tipo: " + tipo + ", Línea: " + linea;
    }
}
