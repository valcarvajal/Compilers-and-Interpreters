package main;

import java.util.*;

/**
 * La clase faseSintactica se encarga del análisis sintáctico basado en una gramática LL(1).
 * Construye el Árbol Sintáctico Abstracto (AST) durante el proceso y detecta errores sintácticos.
 */
public class faseSintactica {
    private final TablaSimbolos tablaSimbolos;
    private final List<String> errores;
    private List<Token> tokens;
    private int indiceToken;
    private Token tokenActual;

    /**
     * Constructor para la clase faseSintactica.
     *
     * @param tablaSimbolos La tabla de símbolos usada durante el análisis sintáctico.
     */
    public faseSintactica(TablaSimbolos tablaSimbolos) {
        this.tablaSimbolos = tablaSimbolos;
        this.errores = new ArrayList<>();
    }

    /**
     * Realiza el análisis sintáctico de una lista de tokens proporcionada y construye el AST.
     *
     * @param tokens La lista de tokens a analizar.
     * @return El nodo raíz del AST construido.
     */
    public NodoAST analizarSintacticamente(List<Token> tokens) {
        this.tokens = tokens;
        this.indiceToken = 0;
        if (tokens.isEmpty()) {
            reportarError("No hay tokens para analizar", 0, "");
            return null;
        }
        this.tokenActual = tokens.get(indiceToken);
        NodoAST programaNodo = programa();

        if (!errores.isEmpty() || programaNodo == null) {
            // Si hay errores o el nodo del programa es null, retornar null
            return null;
        }

        return programaNodo;
    }

    /**
     * Método para analizar la producción 'programa -> expresion ";" { programa }'.
     *
     * @return NodoAST que representa el programa.
     */
    private NodoAST programa() {
        List<NodoAST> expresiones = new ArrayList<>();

        while (tokenActual.obtenerAtributo() != null && indiceToken < tokens.size()) {
            NodoAST expresionNodo = expresion();
            if (expresionNodo == null) {
                return null;
            }
            if (tokenActual.obtenerAtributo() == TipoToken.PUNTO_COMA) {
                consumirToken();
                expresiones.add(expresionNodo);
            } else {
                reportarError("falta token", tokenActual.obtenerLinea(), ";");
                return null;
            }
        }

        return new ProgramaNodo(expresiones);
    }

    /**
     * Método para analizar la producción 'expresion -> identificador "=" expresion | termino { ("+"|"-") termino }'.
     *
     * @return NodoAST que representa la expresión.
     */
    private NodoAST expresion() {
        NodoAST nodo;
        if (tokenActual.obtenerAtributo() == TipoToken.IDENTIFICADOR) {
            Token identificadorToken = tokenActual;
            consumirToken();
            if (tokenActual.obtenerAtributo() == TipoToken.ASIGNACION) {
                consumirToken();
                NodoAST expresionDerecha = expresion();
                if (expresionDerecha == null) {
                    return null;
                }
                nodo = new AsignacionNodo(identificadorToken.obtenerValor(), expresionDerecha, identificadorToken.obtenerLinea());
                // Agregar el identificador a la tabla de símbolos
                tablaSimbolos.agregar(identificadorToken.obtenerValor(), identificadorToken.obtenerLinea());
            } else {
                devolverToken();
                nodo = termino();
                if (nodo == null) {
                    return null;
                }
                nodo = expresionPrima(nodo);
            }
        } else if (esPrimerosTermino(tokenActual)) {
            nodo = termino();
            if (nodo == null) {
                return null;
            }
            nodo = expresionPrima(nodo);
        } else {
            reportarError("expresión inválida en su gramática", tokenActual.obtenerLinea(), tokenActual.obtenerValor());
            return null;
        }
        return nodo;
    }

    /**
     * Método recursivo para manejar la parte recursiva de 'expresion'.
     *
     * @param nodoIzquierdo NodoAST izquierdo.
     * @return NodoAST que representa la expresión completa.
     */
    private NodoAST expresionPrima(NodoAST nodoIzquierdo) {
        if (tokenActual.obtenerAtributo() == TipoToken.SUMA || tokenActual.obtenerAtributo() == TipoToken.RESTA) {
            Token operadorToken = tokenActual;
            consumirToken();
            NodoAST nodoDerecho = termino();
            if (nodoDerecho == null) {
                return null;
            }
            NodoAST nuevoNodo = new OperacionNodo(operadorToken.obtenerValor(), nodoIzquierdo, nodoDerecho, operadorToken.obtenerLinea());
            return expresionPrima(nuevoNodo);
        }
        return nodoIzquierdo;
    }

    /**
     * Método para analizar la producción 'termino -> factor { ("*"|"/") factor }'.
     *
     * @return NodoAST que representa el término.
     */
    private NodoAST termino() {
        NodoAST nodo = factor();
        if (nodo == null) {
            return null;
        }
        return terminoPrima(nodo);
    }

    /**
     * Método recursivo para manejar la parte recursiva de 'termino'.
     *
     * @param nodoIzquierdo NodoAST izquierdo.
     * @return NodoAST que representa el término completo.
     */
    private NodoAST terminoPrima(NodoAST nodoIzquierdo) {
        if (tokenActual.obtenerAtributo() == TipoToken.MULTIPLICACION || tokenActual.obtenerAtributo() == TipoToken.DIVISION) {
            Token operadorToken = tokenActual;
            consumirToken();
            NodoAST nodoDerecho = factor();
            if (nodoDerecho == null) {
                return null;
            }
            NodoAST nuevoNodo = new OperacionNodo(operadorToken.obtenerValor(), nodoIzquierdo, nodoDerecho, operadorToken.obtenerLinea());
            return terminoPrima(nuevoNodo);
        }
        return nodoIzquierdo;
    }

    /**
     * Método para analizar la producción 'factor -> identificador | numero | "(" expresion ")"'.
     *
     * @return NodoAST que representa el factor.
     */
    private NodoAST factor() {
        NodoAST nodo = null;
        if (tokenActual.obtenerAtributo() == TipoToken.IDENTIFICADOR) {
            Token identificadorToken = tokenActual;
            nodo = new IdentificadorNodo(identificadorToken.obtenerValor(), identificadorToken.obtenerLinea());
            consumirToken();
        } else if (tokenActual.obtenerAtributo() == TipoToken.NUMERO) {
            Token numeroToken = tokenActual;
            nodo = new NumeroNodo(numeroToken.obtenerValor(), numeroToken.obtenerLinea());
            consumirToken();
        } else if (tokenActual.obtenerAtributo() == TipoToken.PARENTESIS_IZQ) {
            int lineaActual = tokenActual.obtenerLinea();
            consumirToken();
            nodo = expresion();
            if (nodo == null) {
                return null;
            }
            if (tokenActual.obtenerAtributo() == TipoToken.PARENTESIS_DER) {
                consumirToken();
            } else {
                reportarError("falta token", lineaActual, ")");
                return null;
            }
        } else {
            reportarError("factor inválido en su gramática", tokenActual.obtenerLinea(), tokenActual.obtenerValor());
            return null;
        }
        return nodo;
    }

    /**
     * Método para consumir el siguiente token.
     */
    private void consumirToken() {
        indiceToken++;
        if (indiceToken < tokens.size()) {
            tokenActual = tokens.get(indiceToken);
        } else {
            tokenActual = new DefaultToken("", null, tokenActual.obtenerLinea());
        }
    }

    /**
     * Método para devolver un token en caso de retroceder en el análisis.
     */
    private void devolverToken() {
        indiceToken--;
        if (indiceToken >= 0 && indiceToken < tokens.size()) {
            tokenActual = tokens.get(indiceToken);
        } else {
            tokenActual = new DefaultToken("", null, 0);
        }
    }

    /**
     * Verifica si el token actual pertenece al conjunto PRIMEROS de 'termino'.
     *
     * @param token El token a verificar.
     * @return true si pertenece, false en caso contrario.
     */
    private boolean esPrimerosTermino(Token token) {
        return token.obtenerAtributo() == TipoToken.IDENTIFICADOR ||
               token.obtenerAtributo() == TipoToken.NUMERO ||
               token.obtenerAtributo() == TipoToken.PARENTESIS_IZQ;
    }

    /**
     * Registra un mensaje de error y lo añade a la lista de errores.
     *
     * @param mensaje El mensaje descriptivo del error.
     * @param linea   El número de línea donde se detectó el error.
     * @param token   El token relacionado con el error.
     */
    private void reportarError(String mensaje, int linea, String token) {
        String errorMessage = String.format("Error [Fase Sintáctica]: La línea %d contiene un error en su gramática, %s '%s'", linea, mensaje, token);
        //System.err.println(errorMessage);
        errores.add(errorMessage);
    }

    /**
     * Obtiene la lista de errores ocurridos durante el análisis sintáctico.
     *
     * @return Una lista de cadenas que describen los errores encontrados.
     */
    public List<String> getErrores() {
        return errores;
    }
}
