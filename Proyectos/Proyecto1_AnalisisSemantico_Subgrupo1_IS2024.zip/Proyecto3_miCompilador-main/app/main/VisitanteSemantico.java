package main;

import java.util.*;

public class VisitanteSemantico {
    private Set<String> variablesDeclaradas = new HashSet<>();
    private List<String> errores = new ArrayList<>();

    /**
     * Visita un nodo de programa, procesando cada expresión contenida en él.
     *
     * @param nodo El nodo de programa a visitar.
     */
    public void visitar(ProgramaNodo nodo) {
        for (NodoAST expresion : nodo.expresiones) {
            expresion.aceptar(this);
        }
    }

    /**
     * Visita un nodo de asignación, procesando la expresión y marcando
     * la variable como declarada.
     *
     * @param nodo El nodo de asignación a visitar.
     */
    public void visitar(AsignacionNodo nodo) {
        nodo.expresion.aceptar(this);
        // Marca la variable como declarada después de procesar la expresión
        variablesDeclaradas.add(nodo.identificador);
    }

    /**
     * Visita un nodo de operación, procesando ambos operandos de la operación.
     *
     * @param nodo El nodo de operación a visitar.
     */
    public void visitar(OperacionNodo nodo) {
        nodo.izquierdo.aceptar(this);
        nodo.derecho.aceptar(this);
    }

    /**
     * Visita un nodo de identificador, verificando si la variable ha sido declarada.
     * Si la variable no ha sido declarada, se agrega un mensaje de error.
     *
     * @param nodo El nodo de identificador a visitar.
     */
    public void visitar(IdentificadorNodo nodo) {
        if (!variablesDeclaradas.contains(nodo.nombre)) {
            errores.add("Error [Fase Semántica]: La línea " + nodo.numeroLinea +
                        " contiene un error, no declarado identificador '" + nodo.nombre + "'");
        }
    }

    /**
     * Visita un nodo de número. Los números siempre son válidos, por lo que no
     * se realiza ninguna acción en este método.
     *
     * @param nodo El nodo de número a visitar.
     */
    public void visitar(NumeroNodo nodo) {
    }

    /**
     * Obtiene la lista de errores encontrados durante el análisis semántico.
     *
     * @return Una lista de cadenas que representan los errores semánticos.
     */
    public List<String> getErrores() {
        return errores;
    }
}
