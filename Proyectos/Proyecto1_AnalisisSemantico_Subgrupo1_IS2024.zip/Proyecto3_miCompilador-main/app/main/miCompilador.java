package main;

import java.util.*;

/**
 * La clase `miCompilador` es el punto de entrada principal para ejecutar el compilador.
 * Realiza análisis léxico, sintáctico y semántico en el archivo de entrada proporcionado
 * y muestra los resultados y cualquier error encontrado en cada fase.
 */
public class miCompilador {

    /**
     * El método principal que ejecuta el compilador.
     * Se espera un solo argumento en la línea de comandos que debe ser el nombre del archivo de entrada a compilar.
     * Realiza las siguientes fases de análisis:
     *   Análisis léxico: identifica tokens y errores léxicos.
     *   Análisis sintáctico: construye el árbol de sintaxis y detecta errores sintácticos.
     *   Análisis semántico: valida el árbol semánticamente y reporta cualquier error semántico encontrado.
     *
     * @param args Argumentos de la línea de comandos; debe contener solo el archivo de entrada.
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Uso: java miCompilador [ARCHIVO DE ENTRADA]");
            return;
        }

        String archivoEntrada = args[0];
        DefaultTablaSimbolos tablaSimbolos = new DefaultTablaSimbolos();
        faseLexica faseLexica = new faseLexica(tablaSimbolos);
        faseSintactica faseSintactica = new faseSintactica(tablaSimbolos);
        List<String> erroresLexer;
        List<String> erroresParser;
        List<Token> tokens;

        // Análisis léxico
        tokens = faseLexica.analizarLexicamente(archivoEntrada);
        erroresLexer = faseLexica.getErrores();

        if (erroresLexer.isEmpty()) {
            // Imprime tokens si no hay errores léxicos
            for (Token token : tokens) {
                String tokenInfo = "Valor: " + token.obtenerValor() + ", Tipo: " + token.obtenerAtributo() + ", Línea: " + token.obtenerLinea();
                System.out.println(tokenInfo);
            }

            String mensajeLexicoExito = "--------------------------------------\nAnálisis léxico completado sin errores\n--------------------------------------";
            System.out.println(mensajeLexicoExito);

            // Procede al análisis sintáctico
            NodoAST ast = faseSintactica.analizarSintacticamente(tokens);
            erroresParser = faseSintactica.getErrores();

            if (erroresParser.isEmpty() && ast != null) {
                String mensajeSintacticoExito = "------------------------------------------\nAnálisis sintáctico completado sin errores\n------------------------------------------";
                System.out.println(mensajeSintacticoExito);

                // Procede al análisis semántico
                faseSemantica faseSemantica = new faseSemantica();
                faseSemantica.analizar(ast);
                List<String> erroresSemanticos = faseSemantica.getErrores();

                if (erroresSemanticos.isEmpty()) {
                    String mensajeSemanticoExito = "------------------------------------------\nAnálisis semántico completado sin errores\n------------------------------------------";
                    System.out.println(mensajeSemanticoExito);
                } else {
                    // Imprimir errores semánticos
                    for (String error : erroresSemanticos) {
                        System.err.println(error);
                    }
                }
            } else {
                // Imprimir errores sintácticos si existen
                for (String error : erroresParser) {
                    System.err.println(error);
                }
                String mensajeErrorSintactico = "------------------------------------------\nError [Fase Semántica]: No se puede proceder al análisis semántico debido a errores sintácticos.\n------------------------------------------";
                System.err.println(mensajeErrorSintactico);
            }
        } else {
            // Imprimir errores léxicos si existen
            String mensajeErrorLexico = "------------------------------------------\nError [Fase Semántica]: No se puede proceder al análisis sintáctico debido a errores léxicos.\n------------------------------------------";
            System.err.println(mensajeErrorLexico);
            for (String error : erroresLexer) {
                System.err.println(error);
            }
        }

        // Guardar la tabla de símbolos en un archivo
        tablaSimbolos.guardarEnArchivo();
    }
}
