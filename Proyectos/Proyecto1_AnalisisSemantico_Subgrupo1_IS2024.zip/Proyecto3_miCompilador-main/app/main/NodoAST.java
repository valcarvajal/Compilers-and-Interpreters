package main;

import java.util.List;

/**
 * Clase base abstracta para todos los nodos en el Árbol de Sintaxis Abstracta (AST).
 */
abstract class NodoAST {
    public int numeroLinea;

    /**
     * Constructor de NodoAST.
     *
     * @param numeroLinea El número de línea donde aparece este nodo en el código fuente.
     */
    public NodoAST(int numeroLinea) {
        this.numeroLinea = numeroLinea;
    }

    /**
     * Acepta un visitante semántico para procesar este nodo del AST.
     *
     * @param visitante El visitante semántico.
     */
    public abstract void aceptar(VisitanteSemantico visitante);
}

/**
 * Representa un nodo de programa que contiene una lista de expresiones.
 */
class ProgramaNodo extends NodoAST {
    public List<NodoAST> expresiones;

    /**
     * Constructor de ProgramaNodo.
     *
     * @param expresiones Lista de expresiones en el programa.
     */
    public ProgramaNodo(List<NodoAST> expresiones) {
        super(expresiones.get(0).numeroLinea);
        this.expresiones = expresiones;
    }

    /**
     * Acepta un visitante semántico para procesar este nodo de programa.
     *
     * @param visitante El visitante semántico.
     */
    @Override
    public void aceptar(VisitanteSemantico visitante) {
        visitante.visitar(this);
    }
}

/**
 * Representa un nodo de asignación donde se asigna un valor a una variable.
 */
class AsignacionNodo extends NodoAST {
    public String identificador;
    public NodoAST expresion;

    /**
     * Constructor de AsignacionNodo.
     *
     * @param identificador La variable a la que se asigna.
     * @param expresion La expresión a asignar a la variable.
     * @param numeroLinea El número de línea de la asignación.
     */
    public AsignacionNodo(String identificador, NodoAST expresion, int numeroLinea) {
        super(numeroLinea);
        this.identificador = identificador;
        this.expresion = expresion;
    }

    /**
     * Acepta un visitante semántico para procesar este nodo de asignación.
     *
     * @param visitante El visitante semántico.
     */
    @Override
    public void aceptar(VisitanteSemantico visitante) {
        visitante.visitar(this);
    }
}

/**
 * Representa un nodo de operación con un operador binario y dos operandos.
 */
class OperacionNodo extends NodoAST {
    public String operador;
    public NodoAST izquierdo;
    public NodoAST derecho;

    /**
     * Constructor de OperacionNodo.
     *
     * @param operador El operador de la operación (e.g., "+", "-", "*", "/").
     * @param izquierdo El operando izquierdo.
     * @param derecho El operando derecho.
     * @param numeroLinea El número de línea de la operación.
     */
    public OperacionNodo(String operador, NodoAST izquierdo, NodoAST derecho, int numeroLinea) {
        super(numeroLinea);
        this.operador = operador;
        this.izquierdo = izquierdo;
        this.derecho = derecho;
    }

    /**
     * Acepta un visitante semántico para procesar este nodo de operación.
     *
     * @param visitante El visitante semántico.
     */
    @Override
    public void aceptar(VisitanteSemantico visitante) {
        visitante.visitar(this);
    }
}

/**
 * Representa un nodo de identificador utilizado en expresiones.
 */
class IdentificadorNodo extends NodoAST {
    public String nombre;

    /**
     * Constructor de IdentificadorNodo.
     *
     * @param nombre El nombre del identificador.
     * @param numeroLinea El número de línea donde aparece el identificador.
     */
    public IdentificadorNodo(String nombre, int numeroLinea) {
        super(numeroLinea);
        this.nombre = nombre;
    }

    /**
     * Acepta un visitante semántico para procesar este nodo de identificador.
     *
     * @param visitante El visitante semántico.
     */
    @Override
    public void aceptar(VisitanteSemantico visitante) {
        visitante.visitar(this);
    }
}

/**
 * Representa un nodo de literal numérico en el AST.
 */
class NumeroNodo extends NodoAST {
    public String valor;

    /**
     * Constructor de NumeroNodo.
     *
     * @param valor El valor del literal numérico.
     * @param numeroLinea El número de línea donde aparece el literal.
     */
    public NumeroNodo(String valor, int numeroLinea) {
        super(numeroLinea);
        this.valor = valor;
    }

    /**
     * Acepta un visitante semántico para procesar este nodo de literal numérico.
     *
     * @param visitante El visitante semántico.
     */
    @Override
    public void aceptar(VisitanteSemantico visitante) {
        visitante.visitar(this);
    }
}
