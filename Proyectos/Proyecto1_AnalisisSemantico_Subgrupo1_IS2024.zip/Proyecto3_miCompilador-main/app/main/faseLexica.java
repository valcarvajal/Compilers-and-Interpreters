package main;

import java.util.*;
import java.io.*;
import java.util.logging.Logger;

/**
 * La clase `faseLexica` maneja la fase de análisis léxico del compilador,
 * convirtiendo una secuencia de caracteres en una secuencia de tokens significativos
 * para su uso en fases posteriores del compilador.
 */
public class faseLexica {
    private final Map<TipoToken, DFA> dfaMap;
    private final List<Token> tokens;
    private final List<String> errores;
    private final TablaSimbolos tablaSimbolos;
    private static final Logger LOGGER = Logger.getLogger(faseLexica.class.getName());
    private static final String FORMATO_MENSAJE_ERROR = "Error [Fase Léxica]: La línea %d contiene un error, lexema no reconocido: '%s'";
    private static final int MAX_LONGITUD_LEXEMA = 12;

    /**
     * Inicializa una nueva instancia de la clase `faseLexica`.
     *
     * @param tablaSimbolos La tabla de símbolos utilizada en el análisis léxico.
     */
    public faseLexica(TablaSimbolos tablaSimbolos) {
        this.tokens = new ArrayList<>();
        this.errores = new ArrayList<>();
        this.tablaSimbolos = tablaSimbolos;
        Map<TipoToken, DFA> mydfaMap = new EnumMap<>(TipoToken.class);
        mydfaMap.put(TipoToken.IDENTIFICADOR, inicializarIdentificadorDFA());
        mydfaMap.put(TipoToken.NUMERO, inicializarDigitoDFA());
        mydfaMap.put(TipoToken.ASIGNACION, inicializarAsignacionDFA());
        mydfaMap.put(TipoToken.SUMA, inicializarSumaDFA());
        mydfaMap.put(TipoToken.RESTA, inicializarRestaDFA());
        mydfaMap.put(TipoToken.MULTIPLICACION, inicializarMultiplicacionDFA());
        mydfaMap.put(TipoToken.DIVISION, inicializarDivisionDFA());
        mydfaMap.put(TipoToken.PARENTESIS_IZQ, inicializarParentesisIzqDFA());
        mydfaMap.put(TipoToken.PARENTESIS_DER, inicializarParentesisDerDFA());
        mydfaMap.put(TipoToken.PUNTO_COMA, inicializarPuntoYComaDFA());
        this.dfaMap = mydfaMap;
    }

    /**
     * Inicializa el DFA para reconocer identificadores, que consisten solo en letras minúsculas.
     *
     * @return Una instancia de DFA para identificar identificadores.
     */
    private DFA inicializarIdentificadorDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                if (token.length() == 0 || token.length() > 12) {
                    return false;
                }
                for (char c : token.toCharArray()) {
                    if (c < 'a' || c > 'z') {
                        return false;
                    }
                }
                return true;
            }
        };
    }    

    /**
     * Inicializa el DFA para reconocer literales numéricos.
     *
     * @return Una instancia de DFA para identificar literales numéricos.
     */
    private DFA inicializarDigitoDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                if (token.length() == 0) {
                    return false;
                }
                for (char c : token.toCharArray()) {
                    if (c < '0' || c > '9') {
                        return false;
                    }
                }
                return true;
            }
        };
    }    

    /**
     * Inicializa el DFA para reconocer operadores de asignación ('=').
     *
     * @return Una instancia de DFA para identificar el operador de asignación.
     */
    private DFA inicializarAsignacionDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals("=");
            }
        };
    }

    /**
     * Inicializa el DFA para reconocer el operador de suma ('+').
     *
     * @return Una instancia de DFA para identificar el operador de suma.
     */
    private DFA inicializarSumaDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals("+");
            }
        };
    }

    /**
     * Inicializa el DFA para reconocer el operador de resta ('-').
     *
     * @return Una instancia de DFA para identificar el operador de resta.
     */
    private DFA inicializarRestaDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals("-");
            }
        };
    }

    /**
     * Inicializa el DFA para reconocer el operador de multiplicación ('*').
     *
     * @return Una instancia de DFA para identificar el operador de multiplicación.
     */
    private DFA inicializarMultiplicacionDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals("*");
            }
        };
    }

    /**
     * Inicializa el DFA para reconocer el operador de división ('/').
     *
     * @return Una instancia de DFA para identificar el operador de división.
     */
    private DFA inicializarDivisionDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals("/");
            }
        };
    }

    /**
     * Inicializa el DFA para reconocer el paréntesis izquierdo ('(').
     *
     * @return Una instancia de DFA para identificar el paréntesis izquierdo.
     */
    private DFA inicializarParentesisIzqDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals("(");
            }
        };
    }

    /**
     * Inicializa el DFA para reconocer el paréntesis derecho (')').
     *
     * @return Una instancia de DFA para identificar el paréntesis derecho.
     */
    private DFA inicializarParentesisDerDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals(")");
            }
        };
    }

    /**
     * Inicializa el DFA para reconocer el punto y coma (';').
     *
     * @return Una instancia de DFA para identificar el punto y coma.
     */
    private DFA inicializarPuntoYComaDFA() {
        return new DFA() {
            @Override
            public boolean acepta(String token) {
                return token.equals(";");
            }
        };
    }

    /**
     * Lee el contenido de un archivo de texto ubicado en la ruta especificada y lo devuelve como una cadena.
     *
     * @param filePath La ruta del archivo a leer.
     * @return El contenido del archivo como una cadena.
     */
    private String leerArchivo(String filePath) {
        StringBuilder contenidoArchivo = new StringBuilder();
        try (BufferedReader lector = new BufferedReader(new FileReader(filePath))) {
            String lineaCodigo;
            while ((lineaCodigo = lector.readLine()) != null) {
                contenidoArchivo.append(lineaCodigo).append(System.lineSeparator());
            }
        } catch (Exception e) {
            LOGGER.info(e.getMessage());
        }
        return contenidoArchivo.toString();
    }

    /**
     * Lee el contenido de un archivo de texto, eliminando espacios en blanco y tabulaciones redundantes.
     *
     * @param filePath La ruta del archivo a leer.
     * @return Una cadena que representa el contenido del archivo sin espacios o tabulaciones redundantes.
     */
    public String leerPrograma(String filePath) {
        String contenidoArchivo = leerArchivo(filePath);
        return contenidoArchivo.trim().replaceAll("[ \t]+", "");
    }

    /**
     * Crea un mensaje de error con el formato especificado.
     *
     * @param token       El token que causó el error.
     * @param numeroLinea El número de línea donde se encontró el error.
     * @return El mensaje de error formateado.
     */
    private String crearMensajeError(String token, int numeroLinea) {
        return String.format(FORMATO_MENSAJE_ERROR, numeroLinea, token);
    }

    /**
     * Reporta un mensaje de error si se encuentra un token no reconocido.
     *
     * @param token       El token que causó el error.
     * @param numeroLinea El número de línea donde se encontró el error.
     */
    public void reportarError(String token, int numeroLinea) {
        String errorMessage = crearMensajeError(token, numeroLinea);
        errores.add(errorMessage);
        System.err.println(errorMessage); // Imprime el error inmediatamente
    }

    /**
     * Tokeniza un lexema dado, determinando su tipo utilizando los DFA.
     *
     * @param tokenStr    El lexema a tokenizar.
     * @param numeroLinea El número de línea del token.
     */
    public void tokenizar(String tokenStr, int numeroLinea) {
        Optional<TipoToken> tipoToken = Arrays.stream(TipoToken.values())
                .filter(type -> {
                    DFA dfa = dfaMap.get(type);
                    if (dfa != null) {
                        return dfa.acepta(tokenStr);
                    }
                    return false;
                })
                .findFirst();
        if (tipoToken.isPresent()) {
            Token token = new DefaultToken(tokenStr, tipoToken.get(), numeroLinea);
            tokens.add(token);
            tablaSimbolos.agregar(tokenStr, numeroLinea);
            System.out.println("Valor: " + token.obtenerValor() + ", Tipo: " + token.obtenerAtributo() + ", Línea: " + numeroLinea);
    
        } else {
            reportarError(tokenStr, numeroLinea);
        }
    }
    

    /**
     * Realiza el análisis léxico en un archivo de código fuente, tokenizando
     * identificadores, dígitos y otros símbolos.
     *
     * @param filePath La ruta del archivo que contiene el código fuente a analizar.
     * @return La lista de tokens generados.
     */
    public List<Token> analizarLexicamente(String filePath) {
        String programa = leerPrograma(filePath);
        String[] lineas = programa.split(System.lineSeparator());
        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];
            int numeroLinea = i + 1;
            StringBuilder lexema = new StringBuilder();
            int longitudLinea = linea.length();
            int j = 0;
            while (j < longitudLinea) {
                char caracter = linea.charAt(j);
                if (Character.isLowerCase(caracter)) {
                    j = procesarIdentificador(linea, lexema, numeroLinea, j);
                } else if (Character.isDigit(caracter)) {
                    j = procesarDigito(linea, lexema, numeroLinea, j);
                } else if (esCaracterEspecial(caracter)) {
                    lexema.append(caracter);
                    tokenizar(lexema.toString(), numeroLinea);
                    lexema.setLength(0);
                    j++;
                } else {
                    lexema.append(caracter);
                    reportarError(lexema.toString(), numeroLinea);
                    lexema.setLength(0);
                    j++;
                }
            }
        }
        return tokens;
    }

    /**
     * Procesa un identificador a partir de la línea dada, leyendo caracteres y generando un token.
     *
     * @param linea       La línea de código fuente.
     * @param lexema      El lexema actual que se está procesando.
     * @param numeroLinea El número de línea en el código fuente.
     * @param indice      La posición actual en la línea.
     * @return La nueva posición después de procesar el identificador.
     */
    private int procesarIdentificador(String linea, StringBuilder lexema, int numeroLinea, int indice) {
        lexema.setLength(0);
        int longitudLinea = linea.length();
        while (indice < longitudLinea && Character.isLowerCase(linea.charAt(indice)) && lexema.length() < MAX_LONGITUD_LEXEMA) {
            lexema.append(linea.charAt(indice));
            indice++;
        }
        tokenizar(lexema.toString(), numeroLinea);
        lexema.setLength(0);
        return indice;
    }

    /**
     * Procesa un dígito a partir de la línea dada, leyendo caracteres y generando un token.
     *
     * @param linea       La línea de código fuente.
     * @param lexema      El lexema actual que se está procesando.
     * @param numeroLinea El número de línea en el código fuente.
     * @param indice      La posición actual en la línea.
     * @return La nueva posición después de procesar el dígito.
     */
    private int procesarDigito(String linea, StringBuilder lexema, int numeroLinea, int indice) {
        lexema.setLength(0);
        int longitudLinea = linea.length();
        while (indice < longitudLinea && Character.isDigit(linea.charAt(indice))) {
            lexema.append(linea.charAt(indice));
            indice++;
        }
        tokenizar(lexema.toString(), numeroLinea);
        lexema.setLength(0);
        return indice;
    }

    /**
     * Determina si un carácter es un símbolo especial (operador o puntuación).
     *
     * @param caracter El carácter a verificar.
     * @return True si el carácter es un símbolo especial; de lo contrario, false.
     */
    private boolean esCaracterEspecial(char caracter) {
        return caracter == '+' || caracter == '-' || caracter == '*' || caracter == '/' ||
               caracter == '=' || caracter == ';' || caracter == '(' || caracter == ')';
    }

    /**
     * Obtiene la lista de errores encontrados durante el análisis léxico.
     *
     * @return Una lista de cadenas que describen los errores encontrados.
     */
    public List<String> getErrores() {
        return errores;
    }
}
