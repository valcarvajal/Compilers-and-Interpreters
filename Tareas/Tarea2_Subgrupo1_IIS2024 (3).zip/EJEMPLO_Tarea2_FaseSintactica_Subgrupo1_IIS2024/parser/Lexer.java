package parser;

import java.util.ArrayList;
import java.util.List;

class Lexer {
    private String input;
    private int pos;

    public Lexer(String input) {
        this.input = input;
        this.pos = 0;
    }

    public List<Token> tokenize() {
        List<Token> tokens = new ArrayList<>();
        while (pos < input.length()) {
            char current = input.charAt(pos);
            if (Character.isDigit(current)) {
                tokens.add(new Token("NUMBER", Character.toString(current)));
            } else if (current == '+') {
                tokens.add(new Token("PLUS", "+"));
            } else if (current == '-') {
                tokens.add(new Token("MINUS", "-"));
            } else if (current == '*') {
                tokens.add(new Token("MULTIPLY", "*"));
            } else if (current == '/') {
                tokens.add(new Token("DIVIDE", "/"));
            } else if (current == '(') {
                tokens.add(new Token("LPAREN", "("));
            } else if (current == ')') {
                tokens.add(new Token("RPAREN", ")"));
            }
            pos++;
        }
        tokens.add(new Token("EOF", ""));
        return tokens;
    }
}
