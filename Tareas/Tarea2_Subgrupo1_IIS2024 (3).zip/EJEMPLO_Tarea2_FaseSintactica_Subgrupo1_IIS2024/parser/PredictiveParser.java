package parser;

import java.util.List;

public class PredictiveParser {
    public static void main(String[] args) {
        String input = "3 + ( * 5"; // Ejemplo de expresión con error
        Lexer lexer = new Lexer(input);
        List<Token> tokens = lexer.tokenize();

        Parser parser = new Parser(tokens);
        parser.parse();
    }
}
