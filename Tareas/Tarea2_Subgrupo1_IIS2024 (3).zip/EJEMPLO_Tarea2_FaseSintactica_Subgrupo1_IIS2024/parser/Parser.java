package parser;

import java.util.ArrayList;
import java.util.List;

class Parser {
    private List<Token> tokens;
    private int currentTokenIndex;
    private List<String> correctedTokens;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
        this.currentTokenIndex = 0;
        this.correctedTokens = new ArrayList<>();
    }

    private Token getCurrentToken() {
        return tokens.get(currentTokenIndex);
    }

    private void advance() {
        if (currentTokenIndex < tokens.size() - 1) currentTokenIndex++;
    }

    private void consume(String expectedType) {
        if (getCurrentToken().type.equals(expectedType)) {
            correctedTokens.add(getCurrentToken().value);
            advance();
        } else {
            System.out.println("Error: se esperaba " + expectedType + ", se encontró " + getCurrentToken().type);
            recover(expectedType);
        }
    }

    private void recover(String expectedType) {
        // Método de recuperación: reemplaza el token actual con el esperado
        Token correctedToken = new Token(expectedType, expectedType.equals("NUMBER") ? "0" : expectedType);
        tokens.set(currentTokenIndex, correctedToken);
        correctedTokens.add(correctedToken.value);
        System.out.println("Recuperación: se ha reemplazado con " + expectedType);
        advance();
    }

    public void parse() {
        expression();
        if (!getCurrentToken().type.equals("EOF")) {
            System.out.println("La entrada ha sido corregida y ya no presenta errores sintácticos");
        }
        printCorrectedInput();
    }

    private void expression() {
        term();
        while (getCurrentToken().type.equals("PLUS") || getCurrentToken().type.equals("MINUS")) {
            correctedTokens.add(getCurrentToken().value);
            advance();
            term();
        }
    }

    private void term() {
        factor();
        while (getCurrentToken().type.equals("MULTIPLY") || getCurrentToken().type.equals("DIVIDE")) {
            correctedTokens.add(getCurrentToken().value);
            advance();
            factor();
        }
    }

    private void factor() {
        if (getCurrentToken().type.equals("NUMBER")) {
            consume("NUMBER");
        } else if (getCurrentToken().type.equals("LPAREN")) {
            consume("LPAREN");
            expression();
            consume("RPAREN");
        } else {
            System.out.println("Error: se esperaba un número o '('");
            recover("NUMBER");
        }
    }

    private void printCorrectedInput() {
        System.out.println("Entrada corregida: " + String.join(" ", correctedTokens));
    }
}
